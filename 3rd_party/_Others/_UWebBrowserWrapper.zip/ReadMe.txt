Compile the source code using Delphi. Supports Delphi 7 and above. Not tested
with earlier versions.

Additional features are included in the demo when compiled with Unicode support
(Delphi 2009 and later).

Run the program and read the help information displayed in the program's right
hand "help" pane.
