// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'dfsStatusBar.pas' rev: 5.00

#ifndef dfsStatusBarHPP
#define dfsStatusBarHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dfsstatusbar
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TdfsStatusPanelType { sptNormal, sptCapsLock, sptNumLock, sptScrollLock, sptDate, sptTime, sptDateTime, 
	sptTimeDate, sptEllipsisText, sptEllipsisPath, sptGlyph, sptGauge, sptOwnerDraw };
#pragma option pop

typedef Shortint TPercent;

#pragma option push -b-
enum TdfsGaugeStyle { gsPercent, gsIndeterminate, gsIndeterminate2 };
#pragma option pop

typedef Set<TdfsGaugeStyle, gsPercent, gsIndeterminate2>  TdfsGaugeStyles;

class DELPHICLASS TdfsStatusBar;
class DELPHICLASS TdfsStatusPanel;
typedef void __fastcall (__closure *TdfsDrawPanelEvent)(TdfsStatusBar* StatusBar, TdfsStatusPanel* Panel
	, const Windows::TRect &Rect);

typedef void __fastcall (__closure *TdfsPanelHintTextEvent)(TdfsStatusBar* StatusBar, TdfsStatusPanel* 
	Panel, AnsiString &Hint);

class DELPHICLASS TdfsGaugeAttrs;
class PASCALIMPLEMENTATION TdfsGaugeAttrs : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	TdfsGaugeStyle FStyle;
	TdfsStatusPanel* FOwner;
	TPercent FPosition;
	int FSpeed;
	Graphics::TColor FColor;
	Graphics::TColor FTextColor;
	void __fastcall SetPosition(const TPercent Value);
	void __fastcall SetStyle(const TdfsGaugeStyle Value);
	void __fastcall SetSpeed(const int Value);
	void __fastcall SetColor(const Graphics::TColor Value);
	void __fastcall SetTextColor(const Graphics::TColor Value);
	
public:
	__fastcall TdfsGaugeAttrs(TdfsStatusPanel* AOwner);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__property TdfsStatusPanel* Owner = {read=FOwner};
	
__published:
	__property TdfsGaugeStyle Style = {read=FStyle, write=SetStyle, default=0};
	__property TPercent Position = {read=FPosition, write=SetPosition, default=0};
	__property int Speed = {read=FSpeed, write=SetSpeed, default=4};
	__property Graphics::TColor Color = {read=FColor, write=SetColor, default=-2147483635};
	__property Graphics::TColor TextColor = {read=FTextColor, write=SetTextColor, default=-2147483634};
		
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TdfsGaugeAttrs(void) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TdfsStatusPanel : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	bool FKeyOn;
	TdfsStatusPanelType FPanelType;
	bool FAutoFit;
	bool FEnabled;
	AnsiString FTimeFormat;
	AnsiString FDateFormat;
	AnsiString FText;
	Graphics::TPicture* FGlyph;
	int FGaugeLastPos;
	int FGaugeDirection;
	TdfsDrawPanelEvent FOnDrawPanel;
	AnsiString FHint;
	TdfsPanelHintTextEvent FOnHintText;
	Classes::TNotifyEvent FOnClick;
	TdfsGaugeAttrs* FGaugeAttrs;
	Graphics::TBitmap* FGaugeBitmap;
	Controls::TBorderWidth FBorderWidth;
	void __fastcall SetPanelType(const TdfsStatusPanelType Val);
	Classes::TAlignment __fastcall GetAlignment(void);
	Comctrls::TStatusPanelBevel __fastcall GetBevel(void);
	bool __fastcall IsBiDiModeStored(void);
	Classes::TBiDiMode __fastcall GetBiDiMode(void);
	bool __fastcall GetParentBiDiMode(void);
	int __fastcall GetWidth(void);
	void __fastcall SetAlignment(const Classes::TAlignment Value);
	void __fastcall SetBevel(const Comctrls::TStatusPanelBevel Value);
	void __fastcall SetBiDiMode(const Classes::TBiDiMode Value);
	void __fastcall SetParentBiDiMode(const bool Value);
	void __fastcall SetText(const AnsiString Value);
	void __fastcall SetWidth(const int Value);
	void __fastcall SetAutoFit(const bool Value);
	void __fastcall SetDateFormat(const AnsiString Value);
	void __fastcall SetEnabled(const bool Value);
	void __fastcall SetGlyph(const Graphics::TPicture* Value);
	void __fastcall SetTimeFormat(const AnsiString Value);
	TdfsStatusBar* __fastcall GetStatusBar(void);
	bool __fastcall GetEnabled(void);
	AnsiString __fastcall GetHint();
	void __fastcall SetGaugeAttrs(const TdfsGaugeAttrs* Value);
	Comctrls::TStatusPanel* __fastcall GetLinkedPanel(void);
	Graphics::TBitmap* __fastcall GetGaugeBitmap(void);
	void __fastcall SetBorderWidth(const Controls::TBorderWidth Value);
	bool __fastcall IsTextStored(void);
	
protected:
	virtual void __fastcall SetIndex(int Value);
	virtual AnsiString __fastcall GetDisplayName();
	void __fastcall TimerNotification(void);
	DYNAMIC void __fastcall UpdateAutoFitWidth(void);
	DYNAMIC void __fastcall UpdateDateTime(void);
	DYNAMIC void __fastcall GlyphChanged(System::TObject* Sender);
	DYNAMIC void __fastcall DrawPanel(const Windows::TRect &Rect);
	DYNAMIC void __fastcall EnabledChanged(void);
	DYNAMIC void __fastcall DoHintText(AnsiString &HintText);
	DYNAMIC void __fastcall Redraw(Graphics::TCanvas* Canvas, const Windows::TRect &Dest);
	DYNAMIC void __fastcall DrawKeyLock(Graphics::TCanvas* Canvas, const Windows::TRect &R);
	DYNAMIC void __fastcall DrawTextBased(Graphics::TCanvas* Canvas, const Windows::TRect &R);
	DYNAMIC void __fastcall DrawGlyph(Graphics::TCanvas* Canvas, const Windows::TRect &R);
	DYNAMIC void __fastcall DrawGauge(Graphics::TCanvas* Canvas, const Windows::TRect &R);
	DYNAMIC void __fastcall DrawIndeterminateGauge(Graphics::TCanvas* Canvas, const Windows::TRect &R);
		
	DYNAMIC Graphics::TBitmap* __fastcall InitGaugeBitmap(void);
	DYNAMIC void __fastcall Click(void);
	void __fastcall UpdateKeyboardHook(void);
	__property Comctrls::TStatusPanel* LinkedPanel = {read=GetLinkedPanel};
	__property Graphics::TBitmap* GaugeBitmap = {read=GetGaugeBitmap};
	
public:
	__fastcall virtual TdfsStatusPanel(Classes::TCollection* AOwner);
	__fastcall virtual ~TdfsStatusPanel(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall Invalidate(void);
	__property TdfsStatusBar* StatusBar = {read=GetStatusBar};
	
__published:
	__property TdfsGaugeAttrs* GaugeAttrs = {read=FGaugeAttrs, write=SetGaugeAttrs};
	__property Classes::TAlignment Alignment = {read=GetAlignment, write=SetAlignment, default=0};
	__property Comctrls::TStatusPanelBevel Bevel = {read=GetBevel, write=SetBevel, default=1};
	__property Controls::TBorderWidth BorderWidth = {read=FBorderWidth, write=SetBorderWidth, default=0
		};
	__property Classes::TBiDiMode BiDiMode = {read=GetBiDiMode, write=SetBiDiMode, stored=IsBiDiModeStored
		, nodefault};
	__property bool ParentBiDiMode = {read=GetParentBiDiMode, write=SetParentBiDiMode, default=1};
	__property TdfsStatusPanelType PanelType = {read=FPanelType, write=SetPanelType, default=0};
	__property Graphics::TPicture* Glyph = {read=FGlyph, write=SetGlyph};
	__property AnsiString Text = {read=FText, write=SetText, stored=IsTextStored};
	__property AnsiString DateFormat = {read=FDateFormat, write=SetDateFormat};
	__property AnsiString TimeFormat = {read=FTimeFormat, write=SetTimeFormat};
	__property bool Enabled = {read=GetEnabled, write=SetEnabled, nodefault};
	__property int Width = {read=GetWidth, write=SetWidth, nodefault};
	__property bool AutoFit = {read=FAutoFit, write=SetAutoFit, nodefault};
	__property AnsiString Hint = {read=GetHint, write=FHint};
	__property TdfsDrawPanelEvent OnDrawPanel = {read=FOnDrawPanel, write=FOnDrawPanel};
	__property TdfsPanelHintTextEvent OnHintText = {read=FOnHintText, write=FOnHintText};
	__property Classes::TNotifyEvent OnClick = {read=FOnClick, write=FOnClick};
};


class DELPHICLASS TdfsStatusPanels;
class PASCALIMPLEMENTATION TdfsStatusPanels : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
private:
	Extctrls::TTimer* FTimer;
	Classes::TList* FTimerClients;
	System::TDateTime FLastDate;
	TdfsStatusBar* FStatusBar;
	Comctrls::TStatusPanels* FLinkedPanels;
	HIDESBASE TdfsStatusPanel* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TdfsStatusPanel* Value);
	
protected:
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	void __fastcall RegisterTimer(TdfsStatusPanel* Client);
	void __fastcall DeregisterTimer(TdfsStatusPanel* Client);
	void __fastcall TimerEvent(System::TObject* Sender);
	
public:
	__fastcall TdfsStatusPanels(TdfsStatusBar* StatusBar, Comctrls::TStatusPanels* LinkedPanels);
	__fastcall virtual ~TdfsStatusPanels(void);
	HIDESBASE TdfsStatusPanel* __fastcall Add(void);
	__property TdfsStatusPanel* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
};


class PASCALIMPLEMENTATION TdfsStatusBar : public Comctrls::TStatusBar 
{
	typedef Comctrls::TStatusBar inherited;
	
private:
	TdfsStatusPanels* FPanels;
	Classes::TList* FMainWinHookClients;
	HDC FExtentCanvas;
	HFONT FExtentFont;
	HFONT FExtentFontOld;
	bool FUseMonitorDLL;
	int FDLLClientCount;
	unsigned FKeyHookMsg;
	HIDESBASE void __fastcall SetPanels(const TdfsStatusPanels* Value);
	bool __fastcall AppWinHook(Messages::TMessage &Message);
	MESSAGE void __fastcall WMRefreshLockIndicators(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Msg);
	HIDESBASE MESSAGE void __fastcall CMHintShow(Messages::TMessage &Msg);
	void __fastcall SetOnDrawPanel(const TdfsDrawPanelEvent Value);
	TdfsDrawPanelEvent __fastcall GetOnDrawPanel();
	AnsiString __fastcall GetVersion();
	void __fastcall SetVersion(const AnsiString Val);
	void __fastcall UpdateExtentFont(void);
	void __fastcall SetUseMonitorDLL(const bool Value);
	void __fastcall UpdateKeyboardHooks(void);
	HIDESBASE MESSAGE void __fastcall WMDestroy(Messages::TWMNoParams &Msg);
	HIDESBASE MESSAGE void __fastcall WMPaint(Messages::TWMPaint &Msg);
	
protected:
	DYNAMIC void __fastcall DrawPanel(Comctrls::TStatusPanel* Panel, const Windows::TRect &Rect);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall CreateWnd(void);
	virtual void __fastcall WndProc(Messages::TMessage &Msg);
	Windows::TRect __fastcall GetPanelRect(int Index);
	TdfsStatusPanel* __fastcall FindLinkedPanel(Comctrls::TStatusPanel* Panel);
	void __fastcall RegisterMainWinHook(TdfsStatusPanel* Client);
	void __fastcall DeregisterMainWinHook(TdfsStatusPanel* Client);
	void __fastcall RegisterSystemHook(void);
	void __fastcall DeregisterSystemHook(void);
	tagSIZE __fastcall TextExtent(const AnsiString Text);
	DYNAMIC void __fastcall Click(void);
	
public:
	__fastcall virtual TdfsStatusBar(Classes::TComponent* AOwner);
	__fastcall virtual ~TdfsStatusBar(void);
	void __fastcall InvalidatePanel(int Index);
	
__published:
	__property bool UseMonitorDLL = {read=FUseMonitorDLL, write=SetUseMonitorDLL, default=0};
	__property TdfsStatusPanels* Panels = {read=FPanels, write=SetPanels};
	__property AnsiString Version = {read=GetVersion, write=SetVersion, stored=false};
	__property TdfsDrawPanelEvent OnDrawPanel = {read=GetOnDrawPanel, write=SetOnDrawPanel};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TdfsStatusBar(HWND ParentWindow) : Comctrls::TStatusBar(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Word WM_REFRESHLOCKINDICATORS = 0x80e6;
extern PACKAGE int INDETERMINATE_GAUGE_UPDATE_INTERVAL;
extern PACKAGE System::ResourceString _SCapsLock;
#define Dfsstatusbar_SCapsLock System::LoadResourceString(&Dfsstatusbar::_SCapsLock)
extern PACKAGE System::ResourceString _SNumLock;
#define Dfsstatusbar_SNumLock System::LoadResourceString(&Dfsstatusbar::_SNumLock)
extern PACKAGE System::ResourceString _SScrollLock;
#define Dfsstatusbar_SScrollLock System::LoadResourceString(&Dfsstatusbar::_SScrollLock)
extern PACKAGE TdfsGaugeStyles IndeterminateGuages;

}	/* namespace Dfsstatusbar */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dfsstatusbar;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// dfsStatusBar
