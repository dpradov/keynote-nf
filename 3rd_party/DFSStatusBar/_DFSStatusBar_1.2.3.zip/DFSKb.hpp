// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DFSKb.pas' rev: 5.00

#ifndef DFSKbHPP
#define DFSKbHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dfskb
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString DFSKbDLLName;
extern PACKAGE bool DFSKbDLL_Loaded;
extern PACKAGE void __fastcall InitDFSKbDLL(void);
extern PACKAGE void __fastcall UnloadDFSKbDLL(void);
extern PACKAGE unsigned __fastcall DLLRegisterKeyboardHook(HWND Handle);
extern PACKAGE void __fastcall DLLDeregisterKeyboardHook(HWND Handle);

}	/* namespace Dfskb */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dfskb;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DFSKb
