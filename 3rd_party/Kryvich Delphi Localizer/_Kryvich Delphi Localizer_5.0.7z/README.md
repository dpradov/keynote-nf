# Kryvich's Delphi Localizer 5.0
*Globalize your Delphi applications without troubles*

The Kryvich's Delphi Localizer is a Powerful, Convenient, Flexible, Light, Easy and Free Delphi globalization/localization utility.

K.D.L. 5.0 is designed for Delphi XE2 or newer. It supports all Windows platforms, can be used in VCL and FireMonkey applications, as well as console applications without GUI. If you need a version of the library for older Delphi editions - please visit the project website.

Instructions for use as well as F.A.Q. can be found on the home site.

Please visit the Kryvich's Delphi Localizer home site: https://sites.google.com/site/kryvich/localizer

Copyright (C) 2006-2012, 2018 Kryvich,
Belarusian Linguistic Software team
