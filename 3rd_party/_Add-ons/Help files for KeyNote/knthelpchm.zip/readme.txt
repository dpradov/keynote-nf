Updated KeyNote 1.6.1 HTMLhelp format file (.chm)
March 5, 2003

This zip contains the updated HTMLhelp file for KeyNote version 1.6.1:
keynote.chm
keyhelp.ocx 
readme.txt

To install the new help file:
1. Download the KNHlpchm.zip file.

2. Unless you have created an HTMLHelp file yourself for KeyNote (keynote.chm), one is not included with the standard installation of KeyNote. If you do have a keynote.chm file, then rename the existing keynote.chm file in the KeyNote program directory (or copy  it to a different directory) just in case something goes wrong (or you like the old help file better :-).

3. Unzip the KNHlpchm.zip file into the KeyNote program directory.

For information about KeyNote, go to http://www.tranglos.com/free/keynote.html

If you want the glossary popups in the knhelp.chm file to be popups, and not jumps, you must install keyhelp.ocx. This is an ActiveX Control that enables popups. For more on keyhelp.ocx, go to 
http://www.keyworks.net/keyhelp.htm

1. Copy keyhelp.ocx to the \windows\system32 directory (Windows XP), or to the \windows\system directory  (Windows 98). It goes in the same directory as the regsvr32.exe program.

2. Register keyhelp.ocx.
 a) Open up a DOS window.
 b) Change to the \windows\system32 (or \windows\system) directory.
 c) Type regsvr32.exe keyhelp.ocx
 d) You may have to restart Windows
