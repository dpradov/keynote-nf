KeyNote Wall Calendar Plugin.


Background.
This plugin is basic and not intended to emulate Ecco, Outlook
or any other program. It does not do repeating items, alarms pretty
much what you see is what you get. 


Installation
Put the plug in (knWallCalendar.knl) into the Keynote plug in directory
Put the   KNPWallCalPhone.csv  into the keynote program directory.


Until you save some calendar text you will get a missing file message when starting the plugin.

Edit the csv file as required.


Notes
1. An ini file will be created in your c:\Windows
2. The calendar and journal data is saved in .txt files. This is pretty crude but does the job for now.
Do Not try to edit these txt files yourself - won't work if you do.
3. Double click on the grid to transfer a copy of the text into the selected date 
of the calendar.


3rd Party Delphi Components Used.
The Wall Calendar is based upon a component from Martin Binder.
The Hyperlink component is based on FPURLLabel by Filippo Passeggieri.

Wallace Audley
waudley@gmx.net

)