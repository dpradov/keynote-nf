WebKeyNote v1.00
Freeware
Copyright (C) 2006 by Mikko Hollm�n Olesen
------------------------------------------------------------


TABLE OF CONTENTS
~~~~~~~~~~~~~~~~~

1.  INTRODUCTION
2.  REQUIREMENTS
3.  INSTALLATION & REMOVAL
4.  CHANGE LOG
5.  LICENSE
5a. THIRD PARTY COMPONENTS
6.  CONTACT US



1. INTRODUCTION
============================================================
WebKeyNote was designed to convert KeyNote (.knt) files to 
HTML, retaining the tree-like structure of your notes.

KeyNote 1.6.5 has a function to do this, but it may not
work unless you have the right software on your PC.  This 
is where WebKeyNote comes in.

You can convert your entire KeyNote file to multiple HTML 
files. Simply follow the instructions in "Readme.txt".

See "Usage.txt" to learn more about using WebKeyNote.



2. REQUIREMENTS
============================================================

OS: Windows 95/98/ME/XP/NT/2000
Disk space: 750 KB



3. INSTALLATION & REMOVAL
============================================================
No installation or removal procedures are required. The
program does not read/write to the system registry.

To install, simply unzip the distributed zip file, and run
the "WebKeyNote.exe" program. To unzip the compressed zip 
file, you may need a program like IZarc (freeware) or 
WinZip (Shareware).

To uninstall, just delete all files that were initially
installed, when extracting the zip file (all files are
located within the same folder).



4. CHANGE LOG
============================================================

WebKeyNote v1.00 (March 19, 2006)
- First public release



5. LICENSE
============================================================

LICENSE AGREEMENT
You should carefully read the following terms and 
conditions before installing and/or using the 
software. By installing and/or using this software 
you indicate that you accept the license agreement.

LICENSE
Mikko Olesen grants you a non-exclusive, non-
transferable license to copy the software for your 
personal or commercial use and for freeware 
distribution. 

NO PERMISSION FROM Mikko Olesen IS NECESSARY TO 
INCLUDE THIS SOFTWARE ON CD-ROM OR ANY OTHER MEDIA 
ACCOMPANYING ANY MAGAZINE, BOOK OR OTHER PUBLICATION.

COPYRIGHT
The software is protected by international copyright 
laws and international treaty provisions. Any use of 
the software name is strictly prohibited without the 
written permission of Mikko Olesen.

The software, including its code, appearance, 
structure, design and documentation is an exclusive 
product of Mikko Olesen, who permanently preserves 
all property rights to the software product or its 
copies, modifications or merged parts.

RESTRICTIONS
You may not modify, decompile, disassemble or reverse 
engineer the software. You may not rent, lease or lend 
the software.

NO WARRANTIES
SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY WARRANTY 
AS TO MERCHANTABILITY OR FITNESS FOR A PARTICULAR 
PURPOSE OR ANY OTHER WARRANTIES EITHER EXPRESSED OR 
IMPLIED. Mikko Olesen WILL NOT BE LIABLE FOR DATA 
LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS 
WHILE USING OR MISUSING THIS SOFTWARE.



5a. THIRD PARTY COMPONENTS
============================================================
WebKeyNote uses "Irun.dll", Copyright by Pilot Ltd.



6. CONTACT ME
============================================================

Website: http://www.hollmen.dk

See the website for email and other contact information.