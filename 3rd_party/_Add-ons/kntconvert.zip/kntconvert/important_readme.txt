Important - CHANGE OF URL and ADDRESS
=====================================

As of December 2002, the prorgam you have downloaded
is no longer available at the original site. Please
use the new address:

http://keynote.prv.pl
or
http://www.tranglos.com

(All the applications and documentation previously
available at http://lodz.pdi.net/~eristic/free/
will soon be transferred to the above sites.)

For KeyNote, Oubliette and KookieJar, also see
their respective sites at SourceForge, where
binary and source code downloads are available:

http://sourceforge.net/projects/keynote/
http://sourceforge.net/projects/oubliette/
http://sourceforge.net/projects/kookiejar/

To contact the author, use the following email addresses:
marekjed@users.sourceforge.net
marekjed@pobox.com
marek@tranglos.com

=====================================

