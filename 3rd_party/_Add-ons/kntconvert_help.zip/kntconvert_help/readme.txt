
Help files extracted from kntconvert.hlp with helpdc21.zip (HelpDeco by Sid Penstone):

c:> helpdeco kntconvert.hlp (HelpDeco by Sid Penstone)
 -> 3 files: .hpj, .ph and .rtf

With c:> helpdeco kntconvert.hlp /c 
 -> kntconvert.cnt with a single level.