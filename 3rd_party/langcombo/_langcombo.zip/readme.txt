TLanguagesCombo is native Delphi 3.0 component which
implements drop-down list of languages.

The package contains files:

LCCombo.pas - source code for TLanguagesCombo.
LCCombo.dcu - compiled unit.
LCCombo.dcr - resource file.
Langs.pas   - unit which contains some useful declarations and functions.
Langs.dcu   - compiled unit.
Flags.res   - resource file.
Help.txt    - flat manual.
Readme.txt  - this file.

To install component in Delphi 3 add file LCCombo.pas to
any package you want and compile it.
Find TSpellChecker in Additional page of components palette.
For demo see package of TSpellChecker component.

The software is absolutely freeware.

Author will be grateful for any notes and proposals. 


Alexander Obukhov
Minsk, Belarus
E-mail alex@niiomr.belpak.minsk.by