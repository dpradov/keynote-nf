-----------------------------------------------------------
ERISDATE.KNL
Discordian Date plugin for KeyNote
by Marek Jedlinski
<eristic@lodz.pdi.net>
http://www.lodz.pdi.net/~eristic/free/keynote.html
14 July 2001
-----------------------------------------------------------

This is a sample plugin for KeyNote.
This plugin requires KeyNote version 0.999 or higher.

TO INSTALL:
Unzip the plugin file into the "\plugins" subdirectory, 
below the directory where KeyNote is installed. For example, 
if KeyNote is installed in
	c:\Program Files\Keynote
then the plugin file should be placed in
	c:\Program Files\Keynote\Plugins
This subdirectory is created by the Setup program. You can
create it manually, if necessary.

See "plugins.txt" in KeyNote's "\doc" subdirectory
for information on installing and using plugins.

-----------------------------------------------------------
